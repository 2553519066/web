import{dF as f}from"./index-B0EZE7ii.js";function u(r,t="%"){return f(r)?"":r+t}export{u as v};
