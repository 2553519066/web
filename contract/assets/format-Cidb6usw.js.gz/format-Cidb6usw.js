import{dF as f}from"./index-CeQ2E0rp.js";function u(r,t="%"){return f(r)?"":r+t}export{u as v};
