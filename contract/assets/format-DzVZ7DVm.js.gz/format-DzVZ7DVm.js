import{dF as f}from"./index-BbO6UiJA.js";function u(r,t="%"){return f(r)?"":r+t}export{u as v};
