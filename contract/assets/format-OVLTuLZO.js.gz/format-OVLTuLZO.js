import{dF as f}from"./index-D-MzvSrp.js";function u(r,t="%"){return f(r)?"":r+t}export{u as v};
