import{dF as f}from"./index-D9FXDxt4.js";function u(r,t="%"){return f(r)?"":r+t}export{u as v};
