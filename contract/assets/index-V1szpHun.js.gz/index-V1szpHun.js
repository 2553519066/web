import{_ as f}from"./index-B0EZE7ii.js";export{f as default};
