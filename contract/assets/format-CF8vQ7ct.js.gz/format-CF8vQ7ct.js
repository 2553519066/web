import{dF as f}from"./index-7XFzyDag.js";function u(r,t="%"){return f(r)?"":r+t}export{u as v};
